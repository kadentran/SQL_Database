package application;

import javafx.beans.property.SimpleStringProperty;

/******************************************************************************
 * Class representing data from the table in the library database.  This must
 * be public so the TableView can associate its data elements with the
 * proper columns. 
 ******************************************************************************/

public class Book
{
private final SimpleStringProperty BookID;
private final SimpleStringProperty BookName;
private final SimpleStringProperty Author;
private final SimpleStringProperty Publisher;
private final SimpleStringProperty ISBN;

// Constructor just allocates the properties.
public Book()
{
BookID = new SimpleStringProperty();
BookName = new SimpleStringProperty();
Author = new SimpleStringProperty();
Publisher = new SimpleStringProperty();
ISBN = new SimpleStringProperty();
}
 /**
  * @return the BookID
  */
 public String getBookID()
 {
   return BookID.get();
 }

 public void setBookID(String BookID)
 {
   this.BookID.set(BookID);
 }

 public String getBookName()
 {
   return BookName.get();
 }

 public void setBookName(String BookName)
 {
   this.BookName.set(BookName);
 }

 public String getAuthor()
 {
   return Author.get();
 }

 public void setAuthor(String Author)
 {
   this.Author.set(Author);
 }

 public String getPublisher()
 {
   return Publisher.get();
 }

 public void setPublisher(String Publisher)
 {
   this.Publisher.set(Publisher);
 }

 public String getISBN()
 {
   return ISBN.get();
 }

public void setISBN(String ISBN)
 {
   this.ISBN.set(ISBN);
 }
}  // End of Book class.
