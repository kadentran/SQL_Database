
package application;

import java.sql.*;
import java.util.*;
import java.awt.Paint;
import javafx.application.Application;
import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;


public class Main extends Application {
private static Connection cnSQL;
private static String strSql;
private static Statement stmtSQL;
private String strConnect = "jdbc:mysql://localhost:3306/library?characterEncoding=utf8";
private String user = "root";
private String password = "anhvaem23";
StackPane root;
GridPane grid;
GridPane gpControls,gpControls2;
public TableView lvBook;

public TextField tfBookID;
public TextField tfBookName;
public TextField tfAuthor;
public TextField tfPublisher;
public TextField tfISBN;
public TextField tfResult;


private ObservableList<Book> bookList;


    /***************************************************************************
     * This is the start of the program. Set up the screen here and do other
     * initialization.
     ***************************************************************************/
    @Override
    public void start(Stage primaryStage)
    {
      bookList = FXCollections.observableArrayList();
      
      tfBookID = new TextField();
      tfBookName = new TextField();
      tfAuthor = new TextField();
      tfPublisher = new TextField();
      tfISBN = new TextField();
      
      tfResult = new TextField();
      tfResult.setPrefWidth(600);
      
      root = new StackPane();
      grid = new GridPane();
      lvBook = new TableView();
      TableColumn colID = new TableColumn("Book ID");
      colID.setMinWidth(80);
      TableColumn colBookName = new TableColumn("Book Name");
      colBookName.setMinWidth(150);
      TableColumn colAuthor = new TableColumn("Author");
      colAuthor.setMinWidth(50);
      TableColumn colISBN = new TableColumn("ISBN");
      colISBN.setMinWidth(100);
      TableColumn colPublisher = new TableColumn("Publisher");
      colPublisher.setMinWidth(150);
      
      lvBook.setMinWidth(550);
      lvBook.getColumns().addAll(colID, colBookName, colAuthor, colISBN,colPublisher);
      
      // Set up the data entry controls in their own grid.
      gpControls = new GridPane();
      gpControls.add(new Label("Book ID"), 0, 0);
      gpControls.add(tfBookID, 1, 0);
      gpControls.add(new Label("Author"), 0, 1);
      gpControls.add(tfAuthor, 1,1);
      gpControls.add(new Label("Book Name"),0, 2);
      gpControls.add(tfBookName, 1,2);
      gpControls.add(new Label("Publisher"), 0, 3);
      gpControls.add(tfPublisher, 1,3);
      gpControls.add(new Label("ISBN"), 0, 4);
      gpControls.add(tfISBN, 1,4);
         
      Button btnSearchBook = new Button("Search Book");
      gpControls.add(btnSearchBook, 0, 5);
      btnSearchBook.setOnAction(new SearchButtonPressed());
      
      gpControls2 = new GridPane();
      //gpControls2.setAlignment(Pos.BOTTOM_LEFT);
      gpControls2.add(new Label("Result Console"), 0, 9);
      gpControls2.add(tfResult, 0,10);
      
      // Add CLEAR button
      Button btnCLEAR = new Button("CLEAR");
      gpControls.add(btnCLEAR, 1, 5);
      btnCLEAR.setOnAction(new CLEARButtonPressed());
      
      // Add SAVE button
      Button btnSAVE = new Button("SAVE");
      gpControls.add(btnSAVE, 0 , 6);
      btnSAVE.setOnAction(new SAVEButtonPressed());
      
      // Add Delete button
      Button btnDelete = new Button("Delete");
      gpControls.add(btnDelete, 1 , 6);
      btnDelete.setOnAction(new DeleteButtonPressed());
      
      // Add Update button
      Button btnUpdate = new Button("Update");
      gpControls.add(btnUpdate, 0 , 7);
      btnUpdate.setOnAction(new UpdateButtonPressed());
      
      gpControls.setPadding(new Insets(10, 10 ,15, 10));
      grid.add(gpControls, 0,0);
      grid.add(lvBook, 1, 0);
      grid.add(gpControls2, 0, 1);
      
      colID.setCellValueFactory(new PropertyValueFactory("BookID"));
      colBookName.setCellValueFactory(new PropertyValueFactory("BookName"));
      colAuthor.setCellValueFactory(new PropertyValueFactory("Author"));
      colISBN.setCellValueFactory(new PropertyValueFactory("ISBN"));
      colPublisher.setCellValueFactory(new PropertyValueFactory("Publisher"));
      lvBook.getSelectionModel().selectedItemProperty().addListener(new ListListener());
      
      // Get the Book list and give it to the TableView.
      build(bookList);
      lvBook.setItems(bookList);
      
      
      Scene scene = new Scene(grid, 800, 900);
      
      primaryStage.setTitle("Library");
      primaryStage.setScene(scene);
      primaryStage.show();
    }
    
    /***************************************************************************
     * Open a connection to a Microsoft SQL Server instance that contains the
     * Company database and read the Book table into the list passed as
     * a parameter.
     * @param books -- List of Books for the TableView.
     ***************************************************************************/
    private void build(ObservableList<Book> books)
    {
      //??String strConnect = "jdbc:mysql://CS252748\\SQLEXPRESS:1433;databaseName=company;user=sa;password=SQL1";
      String strdata;
      try
      {
      //???Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
      //???cnSQL = DriverManager.getConnection(strConnect);

      cnSQL = connectDB();
      stmtSQL = cnSQL.createStatement();
      ResultSet rs = stmtSQL.executeQuery("SELECT * FROM Book");
      while (rs.next())
      {
        strdata = rs.getString("BookName") + " " + rs.getString("Author");
        System.out.println(strdata);
        Book book = new Book();
        book.setBookID(rs.getString("ItemNumber"));
        book.setBookName(rs.getString("BookName"));
        book.setAuthor(rs.getString("Author"));
        book.setPublisher(rs.getString("Publisher"));
        book.setISBN(rs.getString("ISBN"));
        books.add(book);
      } 
      //cnSQL.close();
      }
      catch (Exception ex)
      {
      System.out.println("Error: " + ex.getMessage());
      }
    }
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
 public static void main(String[] args) {
    launch(args);
  }
 
 /******************************************************************************
  * Connect to the database and return a Connection object, or null if it
  * failed.  Yes, that object is an instance variable, but it should not be.
  ******************************************************************************/
 
private Connection connectDB()
  {
     try
     {
     Class.forName("com.mysql.jdbc.Driver");
     cnSQL=DriverManager.getConnection(strConnect, user, password);
        }
     catch (Exception ex)
     {
         System.out.println(ex.getMessage());
     }
     return cnSQL;
 }    
 
 
 /******************************************************************************
  * When the "Get ISBN" button is pressed, come here to call a scalar-valued
  * function to retrieve the ISBN using the Book ID from the selected
  * person.
  ******************************************************************************/

// public class ButtonPressed implements EventHandler
// {
//    @Override
//    public void handle(Event event)
//    {
//        //???String strConnect = "jdbc:sqlserver://CS252748\\SQLEXPRESS:1433;databaseName=company;user=sa;password=JohnCole1";
//        try
//        {
//        cnSQL = connectDB();
//        String strID = tfBookID.getText();
//        //???Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//        //???cnSQL = DriverManager.getConnection(strConnect);
//        // Each question mark in the prepared statement below is a positional
//        // parameter that is replaced by the two lines of code following
//        // it.  Note the syntax of the statement in quotes, with braces, etc.
//        CallableStatement cstmt = cnSQL.prepareCall("{? = CALL searchbook(?)}");
//        cstmt.registerOutParameter(1, Types.FLOAT);
//        cstmt.setString(2, strID);
//        cstmt.execute();
//        String bookName = cstmt.getString(1);
//        System.out.println(bookName);
//        tfBookName.setText(bookName);
//        }
//        catch (Exception ex)
//        {
//          System.out.println(ex.getMessage());
//        }
//        finally
//        {
//          try
//          {
//          cnSQL.close();
//          }
//          catch (Exception ex)
//          {}
//        }
//    }
// }  // End of ButtonPressed class.
 
 public class SearchButtonPressed implements EventHandler
 {
    @Override
    public void handle(Event event)
    {
        
        try
        {
        cnSQL = connectDB();
        String strBookID = tfBookID.getText();
        
        String strAuthor = tfAuthor.getText();
        String strBookName = tfBookName.getText();
        String strPublisher = tfPublisher.getText();
        String strISBN = tfISBN.getText();
        
        int intBookID=0;
        String searchByID = null;
        if (strBookID != null && !strBookID.isEmpty()) {
        	intBookID = Integer.parseInt(strBookID);
        	searchByID = 
    				"SELECT * FROM book WHERE\n" +		        		
    				"ItemNumber = "+intBookID+";";
        	System.out.println("intBookID :"+intBookID);
        }
        
        
        String searchByBookName = 
				"SELECT * FROM book WHERE\n" +		        		
				"BookName  LIKE '%"+strBookName+"%';"
				;
        String searchByAuthor = 
				"SELECT * FROM book WHERE\n" +		        		
				"Author LIKE '%"+strAuthor+"%';"
				;
        String searchByPublisher = 
				"SELECT * FROM book WHERE\n" +		        		
				"Publisher LIKE '%"+strPublisher+"%';"
				;
        
        String searchByISBN = 
				"SELECT * FROM book WHERE\n" +		        		
				"ISBN = "+strISBN+";"
				;
        System.out.println("intBookID :"+intBookID);
        
        String sqlStmt=null;
        if (strBookID != null && !strBookID.isEmpty()) {
        	sqlStmt = searchByID;
        }
        else if (strBookName != null && !strBookName.isEmpty()) {
        	sqlStmt = searchByBookName;
        }
        else if (strAuthor != null && !strAuthor.isEmpty()) {
        	sqlStmt = searchByAuthor;
        }
        else if (strPublisher != null && !strPublisher.isEmpty()) {
        	sqlStmt = searchByPublisher;
        }
        else if (strISBN != null && !strISBN.isEmpty()) {
        	sqlStmt = searchByISBN;
        }
        
        
		System.out.println(sqlStmt);		
        String strdata;
        
        List<Book> list = new ArrayList<Book>();
        ObservableList<Book> books = FXCollections.observableList(list);
       
		 ResultSet rs = stmtSQL.executeQuery(sqlStmt);
		 //System.out.println(rs);
	      while (rs.next())
	      {
	        strdata = rs.getString("BookName") + " " + rs.getString("Author");
	        System.out.println(strdata);
	        Book book = new Book();
	        book.setBookID(rs.getString("ItemNumber"));
	        book.setBookName(rs.getString("BookName"));
	        book.setAuthor(rs.getString("Author"));
	        book.setPublisher(rs.getString("Publisher"));
	        book.setISBN(rs.getString("ISBN"));
	        books.add(book);
	      }
	      
		// Get the updated Book list and give it to the TableView.
		lvBook.getItems().clear();
		//build(bookList);
		lvBook.setItems(books);
		tfResult.setText("Book found");
		
        }
        catch (Exception ex)
        {
          System.out.println(ex.getMessage());
          tfResult.setText(ex.getMessage());
        }
        finally
        {
          try
          {
          //cnSQL.close();
          }
          catch (Exception ex)
          {}
        }
    }
 }  // End of SearchButtonPressed class.
 
 public class CLEARButtonPressed implements EventHandler
 {
	    @Override
	    public void handle(Event event)
	    {
	    	tfBookID.setText("");
	        tfBookName.setText("");
	        tfAuthor.setText("");
	        tfPublisher.setText("");
	        tfISBN.setText("");
	    }
	 }  // End of CLEARButtonPressed class.
 
 public class SAVEButtonPressed implements EventHandler
 {
    @Override
    public void handle(Event event)
    {
        
        try
        {
        cnSQL = connectDB();
        stmtSQL = cnSQL.createStatement();
        
        int intBookID = Integer.parseInt(tfBookID.getText());
        String strAuthor = tfAuthor.getText();
        String strBookName = tfBookName.getText();
        String strPublisher = tfPublisher.getText();
        String strISBN = tfISBN.getText();
               
        String sqlStmt = 
        		        "INSERT INTO book\n" +
                        "(ItemNumber, Author, BookName, Publisher, ISBN)\n" +
                        "VALUES\n" +
                        "('"+intBookID+"','"+strAuthor+"','"+strBookName+"','"+strPublisher+"','"+strISBN+"');" ;
                        
        
        //System.out.println(sqlStmt);
        stmtSQL.executeUpdate(sqlStmt);
        //stmtSQL.executeQuery(sqlStmt);
        
        // Get the updated Book list and give it to the TableView.
        lvBook.getItems().clear();
        build(bookList);
        lvBook.setItems(bookList);
        
        tfResult.setText("Added book");
        }
        catch (Exception ex)
        {
          System.out.println(ex.getMessage());
          tfResult.setText(ex.getMessage());
        }
        finally
        {
          try
          {
          //cnSQL.close();
          }
          catch (Exception ex)
          {}
        }
    }
 }  // End of SAVEButtonPressed class.
 
 public class DeleteButtonPressed implements EventHandler
 {
    @Override
    public void handle(Event event)
    {
        
        try
        {
        cnSQL = connectDB();
        stmtSQL = cnSQL.createStatement();
        
        int intBookID = Integer.parseInt(tfBookID.getText());
        //String strAuthor = tfAuthor.getText();
        //String strBookName = tfBookName.getText();
        //String strPublisher = tfPublisher.getText();
        //String strISBN = tfISBN.getText();
                
        String sqlStmt = 
        		        "Delete from book WHERE\n" +
                        "ItemNumber = '"+intBookID+"';"
                        ;                   
        
        System.out.println(sqlStmt);
        stmtSQL.executeUpdate(sqlStmt);
        //stmtSQL.executeQuery(sqlStmt);
        
        // Get the updated Book list and give it to the TableView.
        lvBook.getItems().clear();
        build(bookList);
        lvBook.setItems(bookList);
        tfResult.setText("Deleted book");
        }
        catch (Exception ex)
        {
          System.out.println(ex.getMessage());
          tfResult.setText(ex.getMessage());
        }
        finally
        {
          try
          {
          //cnSQL.close();
          }
          catch (Exception ex)
          {}
        }
    }
 }  // End of DeleteButtonPressed class.
 
 public class UpdateButtonPressed implements EventHandler
 {
    @Override
    public void handle(Event event)
    {
        
        try
        {
        cnSQL = connectDB();
        stmtSQL = cnSQL.createStatement();
        
        int intBookID = Integer.parseInt(tfBookID.getText());
        String strAuthor = tfAuthor.getText();
        String strBookName = tfBookName.getText();
        String strPublisher = tfPublisher.getText();
        String strISBN = tfISBN.getText();
                
        String sqlStmt = 
        		        "UPDATE book\n" +
                        "SET Author = '"+strAuthor+"',BookName = '"+strBookName+"',Publisher = '"+strPublisher+"',ISBN = '"+strISBN+"' "+
                        "WHERE\n" +
                        "ItemNumber = '"+intBookID+"';"
                        ;                   
        
        System.out.println(sqlStmt);
        stmtSQL.executeUpdate(sqlStmt);
        //stmtSQL.executeQuery(sqlStmt);
        
        // Get the updated Book list and give it to the TableView.
        lvBook.getItems().clear();
        build(bookList);
        lvBook.setItems(bookList);
        
        tfResult.setText("Updated book");
        }
        catch (Exception ex)
        {
          System.out.println(ex.getMessage());
          tfResult.setText(ex.getMessage());
        }
        finally
        {
          try
          {
          //cnSQL.close();
          }
          catch (Exception ex)
          {}
        }
    }
 }  // End of UpdateButtonPressed class.
 
 /******************************************************************************
  * This is invoked when the selection in the TableView changes.  I don't like
  * the way this works.  It does not pass a reference to the list, so we have
  * to know which one it was.  With only one list, that is okay.  The newValue
  * parameter is the object that was selected.
  ******************************************************************************/

public class ListListener implements ChangeListener
 {
    @Override
    public void changed(ObservableValue observable, Object oldValue, Object newValue)
    {
      Book e = (Book)newValue;
      tfBookID.setText(e.getBookID());
      tfBookName.setText(e.getBookName());
      tfAuthor.setText(e.getAuthor());
      tfPublisher.setText(e.getPublisher());
      tfISBN.setText(e.getISBN());
      // Only here to show how to get this index, if you need it.
      int iRow = lvBook.getSelectionModel().getSelectedIndex();
      //???throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 }  // End of ListListener class.
 
}